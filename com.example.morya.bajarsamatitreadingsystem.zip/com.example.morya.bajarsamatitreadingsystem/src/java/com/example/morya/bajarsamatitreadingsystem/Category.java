/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.SubCategory;

public class Category
extends AppCompatActivity {
    public static int catCnt = 0;
    public static String catnm;
    ListView ct;
    ImageView dals;
    ImageView flower;
    ImageView fruit;
    String[] fruits = new String[]{"Fruit", "Flowers", "Vegetables", "Lentil", "Pulses", "Grains"};
    ImageView grain;
    ImageView sugar;
    ImageView veg;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968611);
        this.veg = (ImageView)this.findViewById(2131558579);
        this.fruit = (ImageView)this.findViewById(2131558580);
        this.sugar = (ImageView)this.findViewById(2131558581);
        this.dals = (ImageView)this.findViewById(2131558578);
        this.grain = (ImageView)this.findViewById(2131558588);
        this.flower = (ImageView)this.findViewById(2131558587);
        this.veg.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 3;
                Category.catnm = "Vegetables";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
        this.flower.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 2;
                Category.catnm = "Flower";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
        this.grain.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 6;
                Category.catnm = "Grain";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
        this.fruit.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 1;
                Category.catnm = "Fruit";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
        this.dals.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 5;
                Category.catnm = "Pulses";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
        this.sugar.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Category.catCnt = 4;
                Category.catnm = "Lentils";
                Toast.makeText((Context)Category.this.getApplicationContext(), (CharSequence)("You have selected" + Category.catnm), (int)0).show();
                Intent intent = new Intent(Category.this.getApplicationContext(), SubCategory.class);
                Category.this.startActivity(intent);
            }
        });
    }

}

