/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.EditBazarSamiti;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class EditDetails
extends AppCompatActivity {
    public static String add;
    public static String cpass;
    public static String mail;
    public static String mob;
    public static String nm;
    public static String pass;
    EditText address;
    EditText contact;
    final Context context = this;
    EditText cpassword;
    EditText email;
    EditText name;
    EditText password;
    private ProgressDialog progress;
    String receivedValue = "";
    Button register;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968615);
        this.register = (Button)this.findViewById(2131558560);
        this.name = (EditText)this.findViewById(2131558554);
        this.email = (EditText)this.findViewById(2131558556);
        this.address = (EditText)this.findViewById(2131558557);
        this.password = (EditText)this.findViewById(2131558558);
        this.cpassword = (EditText)this.findViewById(2131558559);
        this.contact = (EditText)this.findViewById(2131558555);
        Toast.makeText((Context)this, (CharSequence)("Samiti Name => " + EditBazarSamiti.samitinm), (int)0).show();
        this.name.setText((CharSequence)EditBazarSamiti.samitinm);
        this.contact.setText((CharSequence)EditBazarSamiti.s_mobile);
        this.email.setText((CharSequence)EditBazarSamiti.s_email);
        this.address.setText((CharSequence)EditBazarSamiti.s_address);
        this.password.setText((CharSequence)EditBazarSamiti.s_pass);
        this.cpassword.setText((CharSequence)EditBazarSamiti.s_pass);
        this.name.setEnabled(false);
        this.register.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                EditDetails.nm = EditDetails.this.name.getText().toString();
                EditDetails.mob = EditDetails.this.contact.getText().toString();
                EditDetails.mail = EditDetails.this.email.getText().toString();
                EditDetails.add = EditDetails.this.address.getText().toString();
                EditDetails.pass = EditDetails.this.password.getText().toString();
                EditDetails.cpass = EditDetails.this.cpassword.getText().toString();
                if (EditDetails.nm.equals((Object)"")) {
                    EditDetails.this.name.setError((CharSequence)"Enter Name");
                    return;
                }
                if (EditDetails.mob.equals((Object)"") || EditDetails.mob.length() < 10) {
                    EditDetails.this.contact.setError((CharSequence)"Check Mobile no");
                    return;
                }
                if (EditDetails.add.equals((Object)"")) {
                    EditDetails.this.address.setError((CharSequence)"Enter Address");
                    return;
                }
                if (EditDetails.pass.equals((Object)"") || EditDetails.pass.length() < 4) {
                    EditDetails.this.password.setError((CharSequence)"Password Should not be less than 4 char");
                    return;
                }
                if (!EditDetails.pass.equals((Object)EditDetails.cpass)) {
                    EditDetails.this.cpassword.setError((CharSequence)"Enter correct password");
                    return;
                }
                try {
                    EditDetails.this.progress = new ProgressDialog(EditDetails.this.context);
                    EditDetails.this.progress.setMessage((CharSequence)"Wait...");
                    EditDetails.this.progress.setProgressStyle(0);
                    EditDetails.this.progress.setIndeterminate(false);
                    EditDetails.this.progress.setProgress(0);
                    EditDetails.this.progress.setCancelable(false);
                    EditDetails.this.progress.show();
                    new addBajarSamiti().execute((Object[])new String[0]);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)EditDetails.this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
                    return;
                }
            }
        });
    }

    private class addBajarSamiti
    extends AsyncTask<String, Void, String> {
        private addBajarSamiti() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//editBazar.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("e1", EditDetails.nm));
            arrayList.add((Object)new BasicNameValuePair("e2", EditDetails.mob));
            arrayList.add((Object)new BasicNameValuePair("e3", EditDetails.add));
            arrayList.add((Object)new BasicNameValuePair("e4", EditDetails.mail));
            arrayList.add((Object)new BasicNameValuePair("e5", EditDetails.pass));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                EditDetails.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            EditDetails.this.progress.dismiss();
            Toast.makeText((Context)EditDetails.this.context, (CharSequence)EditDetails.this.receivedValue, (int)0).show();
            if (EditDetails.this.receivedValue.contains((CharSequence)"exists")) {
                Toast.makeText((Context)EditDetails.this.context, (CharSequence)"UserId Already Exists", (int)0).show();
                return;
            } else {
                if (!EditDetails.this.receivedValue.contains((CharSequence)"success")) return;
                {
                    Toast.makeText((Context)EditDetails.this.context, (CharSequence)"Record updated Successfully!!!!!", (int)0).show();
                    EditDetails.this.finish();
                    return;
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

