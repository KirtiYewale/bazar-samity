/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Login;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class Register
extends AppCompatActivity {
    public static String add;
    public static String cpass;
    public static String mob;
    public static String nm;
    public static String pass;
    EditText address;
    EditText contact;
    final Context context = this;
    EditText cpassword;
    EditText name;
    EditText password;
    private ProgressDialog progress;
    String receivedValue = "";
    Button register;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968619);
        this.register = (Button)this.findViewById(2131558560);
        this.name = (EditText)this.findViewById(2131558554);
        this.address = (EditText)this.findViewById(2131558557);
        this.password = (EditText)this.findViewById(2131558558);
        this.cpassword = (EditText)this.findViewById(2131558559);
        this.contact = (EditText)this.findViewById(2131558555);
        this.register.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Register.nm = Register.this.name.getText().toString();
                Register.mob = Register.this.contact.getText().toString();
                Register.add = Register.this.address.getText().toString();
                Register.pass = Register.this.password.getText().toString();
                Register.cpass = Register.this.cpassword.getText().toString();
                if (Register.nm.equals((Object)"")) {
                    Register.this.name.setError((CharSequence)"Enter Name");
                    return;
                }
                if (Register.mob.equals((Object)"") || Register.mob.length() != 10) {
                    Register.this.contact.setError((CharSequence)"Check Mobile no");
                    return;
                }
                if (Register.add.equals((Object)"")) {
                    Register.this.address.setError((CharSequence)"Enter Address");
                    return;
                }
                if (Register.pass.equals((Object)"") || Register.pass.length() < 4) {
                    Register.this.password.setError((CharSequence)"Password Should not be less than 4 char");
                    return;
                }
                if (!Register.pass.equals((Object)Register.cpass)) {
                    Register.this.cpassword.setError((CharSequence)"Enter correct password");
                    return;
                }
                try {
                    Register.this.progress = new ProgressDialog(Register.this.context);
                    Register.this.progress.setMessage((CharSequence)"Wait...");
                    Register.this.progress.setProgressStyle(0);
                    Register.this.progress.setIndeterminate(false);
                    Register.this.progress.setProgress(0);
                    Register.this.progress.setCancelable(false);
                    Register.this.progress.show();
                    new addUser().execute((Object[])new String[0]);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)Register.this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
                    return;
                }
            }
        });
    }

    private class addUser
    extends AsyncTask<String, Void, String> {
        private addUser() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//addUser.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("e1", Register.nm));
            arrayList.add((Object)new BasicNameValuePair("e2", Register.mob));
            arrayList.add((Object)new BasicNameValuePair("e3", Register.add));
            arrayList.add((Object)new BasicNameValuePair("e4", Register.pass));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                Register.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            Register.this.progress.dismiss();
            Toast.makeText((Context)Register.this.context, (CharSequence)Register.this.receivedValue, (int)0).show();
            if (Register.this.receivedValue.contains((CharSequence)"exists")) {
                Toast.makeText((Context)Register.this.context, (CharSequence)"UserId Already Exists", (int)0).show();
                return;
            } else {
                if (!Register.this.receivedValue.contains((CharSequence)"success")) return;
                {
                    Toast.makeText((Context)Register.this.context, (CharSequence)"Registered Successfully", (int)0).show();
                    Intent intent = new Intent(Register.this.getApplicationContext(), Login.class);
                    Register.this.startActivity(intent);
                    Register.this.finish();
                    return;
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

