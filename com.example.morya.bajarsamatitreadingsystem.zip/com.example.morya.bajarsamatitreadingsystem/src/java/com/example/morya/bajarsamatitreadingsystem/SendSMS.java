/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.telephony.gsm.SmsManager
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.PendingIntent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.gsm.SmsManager;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SendSMS
extends AppCompatActivity {
    EditText msg;
    Button send;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968620);
        this.msg = (EditText)this.findViewById(2131558607);
        this.send = (Button)this.findViewById(2131558608);
        this.send.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                String string2 = SendSMS.this.msg.getText().toString();
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("8830842042", null, string2, null, null);
                smsManager.sendTextMessage("9146249836", null, string2, null, null);
                smsManager.sendTextMessage("9158835780", null, string2, null, null);
            }
        });
    }

}

