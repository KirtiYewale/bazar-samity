/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.EditDetails;
import com.example.morya.bajarsamatitreadingsystem.simplebajarsamitilist;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

public class EditBazarSamiti
extends AppCompatActivity {
    private static final String TAG_RESULTS = "result";
    public static String s_address;
    public static String s_email;
    public static String s_mobile;
    public static String s_pass;
    public static int samiticnt;
    public static String samitinm;
    public static int visited;
    String[] BajarSamiti;
    String[] address;
    ListView bl;
    final Context context = this;
    String day;
    int day1;
    String[] email;
    String[] mobile;
    String[] pass;
    JSONArray peoples = null;
    private ProgressDialog progress;
    String receivedValue = "";
    String stringRate;

    static {
        samiticnt = 0;
        visited = 0;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968614);
        this.bl = (ListView)this.findViewById(2131558574);
        this.progress = new ProgressDialog(this.context);
        this.progress.setMessage((CharSequence)"Wait...");
        this.progress.setProgressStyle(0);
        this.progress.setIndeterminate(false);
        this.progress.setProgress(0);
        this.progress.setCancelable(false);
        this.progress.show();
        new getdata().execute((Object[])new String[0]);
        this.bl.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(final AdapterView<?> adapterView, View view, final int n, long l) {
                EditBazarSamiti.samiticnt = n + 1;
                Toast.makeText((Context)EditBazarSamiti.this, (CharSequence)("" + EditBazarSamiti.samitinm), (int)0).show();
                EditBazarSamiti.visited = 1;
                AlertDialog.Builder builder = new AlertDialog.Builder(EditBazarSamiti.this.context);
                builder.setMessage((CharSequence)"Are you sure you want to edit this record? ");
                builder.setCancelable(false);
                builder.setPositiveButton((CharSequence)"CONFIRM", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n2) {
                        EditBazarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        EditBazarSamiti.s_mobile = EditBazarSamiti.this.mobile[n];
                        EditBazarSamiti.s_email = EditBazarSamiti.this.email[n];
                        EditBazarSamiti.s_address = EditBazarSamiti.this.address[n];
                        EditBazarSamiti.s_pass = EditBazarSamiti.this.pass[n];
                        EditBazarSamiti.this.startActivity(new Intent(EditBazarSamiti.this.getApplicationContext(), EditDetails.class));
                    }
                });
                builder.setNegativeButton((CharSequence)"NO", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
            }

        });
    }

    protected void showList() {
        this.peoples = new JSONObject(this.receivedValue).getJSONArray(TAG_RESULTS);
        this.BajarSamiti = new String[this.peoples.length()];
        this.mobile = new String[this.peoples.length()];
        this.email = new String[this.peoples.length()];
        this.address = new String[this.peoples.length()];
        this.pass = new String[this.peoples.length()];
        int n = 0;
        do {
            if (n >= this.peoples.length()) break;
            JSONObject jSONObject = this.peoples.getJSONObject(n);
            this.BajarSamiti[n] = jSONObject.getString("v1");
            this.mobile[n] = jSONObject.getString("v2");
            this.email[n] = jSONObject.getString("v3");
            this.address[n] = jSONObject.getString("v4");
            this.pass[n] = jSONObject.getString("v5");
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.BajarSamiti);
            this.bl.setAdapter((ListAdapter)arrayAdapter);
            this.progress.dismiss();
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)("Error3=" + exception.toString()), (int)0).show();
            return;
        }
    }

    private class getdata
    extends AsyncTask<String, Void, String> {
        private getdata() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//getSamiti.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("sam", simplebajarsamitilist.samitinm));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                EditBazarSamiti.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            EditBazarSamiti.this.showList();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

