/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Admin;
import com.example.morya.bajarsamatitreadingsystem.BajarSamiti_Panel;
import com.example.morya.bajarsamatitreadingsystem.Register;
import com.example.morya.bajarsamatitreadingsystem.User;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class Login
extends AppCompatActivity {
    public static String Samuname;
    public static String option;
    public static String pwdString;
    public static String receivedValue;
    public static String unameString;
    final Context context = this;
    SQLiteDatabase db;
    Button login;
    private ProgressDialog progress;
    EditText pwd;
    Button signup;
    EditText uname;

    static {
        receivedValue = "";
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968618);
        this.uname = (EditText)this.findViewById(2131558602);
        this.pwd = (EditText)this.findViewById(2131558603);
        this.login = (Button)this.findViewById(2131558605);
        this.signup = (Button)this.findViewById(2131558606);
        Samuname = "";
        this.db = this.openOrCreateDatabase("Labor", 0, null);
        this.db.execSQL("create table if not exists register (Username varchar(255))");
        this.login.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Login.unameString = Login.this.uname.getText().toString();
                Login.pwdString = Login.this.pwd.getText().toString();
                if (Login.unameString.equals((Object)"")) {
                    Login.this.uname.setError((CharSequence)"Enter Username");
                    return;
                }
                if (Login.pwdString.equals((Object)"")) {
                    Login.this.pwd.setError((CharSequence)"Enter Password");
                    return;
                }
                if (Login.unameString.equals((Object)"admin") && Login.pwdString.equals((Object)"admin")) {
                    Intent intent = new Intent(Login.this.getApplicationContext(), Admin.class);
                    Login.this.startActivity(intent);
                    return;
                }
                if (Login.unameString.equals((Object)"admin") && Login.pwdString.equals((Object)"admin")) {
                    Toast.makeText((Context)Login.this.context, (CharSequence)"Login Successfully...!!!", (int)0).show();
                    Intent intent = new Intent(Login.this.getApplicationContext(), Admin.class);
                    Login.this.startActivity(intent);
                    return;
                }
                Login.this.progress = new ProgressDialog(Login.this.context);
                Login.this.progress.setMessage((CharSequence)"Wait...");
                Login.this.progress.setProgressStyle(0);
                Login.this.progress.setIndeterminate(false);
                Login.this.progress.setProgress(0);
                Login.this.progress.setCancelable(false);
                Login.this.progress.show();
                new login().execute((Object[])new String[0]);
            }
        });
        this.signup.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Intent intent = new Intent(Login.this.getApplicationContext(), Register.class);
                Login.this.startActivity(intent);
            }
        });
    }

    private class login
    extends AsyncTask<String, Void, String> {
        private login() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//login.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("e1", Login.unameString));
            arrayList.add((Object)new BasicNameValuePair("e2", Login.pwdString));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                Login.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)new BasicResponseHandler());
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            Login.this.progress.dismiss();
            Toast.makeText((Context)Login.this.context, (CharSequence)Login.receivedValue, (int)0).show();
            if (Login.receivedValue.contains((CharSequence)"user")) {
                Toast.makeText((Context)Login.this, (CharSequence)"Login Successfully to user Panel", (int)0).show();
                Intent intent = new Intent(Login.this.getApplicationContext(), User.class);
                Login.this.startActivity(intent);
                Login.this.finish();
            } else if (Login.receivedValue.contains((CharSequence)"bajar")) {
                Toast.makeText((Context)Login.this, (CharSequence)"Login Successfully to samiti Panel", (int)0).show();
                Login.Samuname = Login.unameString;
                Intent intent = new Intent(Login.this.getApplicationContext(), BajarSamiti_Panel.class);
                Login.this.startActivity(intent);
                Login.this.finish();
            } else {
                Toast.makeText((Context)Login.this.context, (CharSequence)"Invalid Authentication", (int)0).show();
            }
            if (Login.receivedValue.contains((CharSequence)"wro")) {
                Toast.makeText((Context)Login.this.context, (CharSequence)"Invalid Authentication", (int)0).show();
                return;
            } else {
                if (!Login.receivedValue.contains((CharSequence)"success")) return;
                {
                    Toast.makeText((Context)Login.this.context, (CharSequence)"Login Successfully", (int)0).show();
                    return;
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

