/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

public class url {
    public static final String url = "http://bazarsamiti.co.nf/";
}

