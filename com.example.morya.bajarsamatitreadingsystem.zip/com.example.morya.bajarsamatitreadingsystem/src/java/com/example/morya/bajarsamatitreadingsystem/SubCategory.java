/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.AddQty;
import com.example.morya.bajarsamatitreadingsystem.AddRate;
import com.example.morya.bajarsamatitreadingsystem.BajarSamiti_Panel;
import com.example.morya.bajarsamatitreadingsystem.BazarsamitiViewRates;
import com.example.morya.bajarsamatitreadingsystem.Category;
import com.example.morya.bajarsamatitreadingsystem.ViewRates;

public class SubCategory
extends AppCompatActivity {
    public static int cnt;
    public static int scatCnt;
    public static String scatnm;
    String[] crispers = new String[]{"Tomato", "Potato", "Brinjal"};
    String[] flowers = new String[]{"Rose", "Sunflower", "Daisy"};
    String[] fruits = new String[]{"Mango", "Apple", "Banana", "Chickoo"};
    String[] grain = new String[]{"Wheat", "Bajara", "Jowar"};
    String[] lentil = new String[]{"Mug", "Chavli", "Harbhara"};
    String[] pulses = new String[]{"Harbhara Dal", "Mug Dal"};
    ListView sct;
    String[] veg = new String[]{"Methi", "Palak", "Shepu", "Kothimbir"};

    static {
        scatCnt = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968623);
        this.sct = (ListView)this.findViewById(2131558610);
        cnt = Category.catCnt;
        if (cnt == 1) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.fruits);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 2) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.flowers);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 3) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.veg);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 4) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.lentil);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 5) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.pulses);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 6) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.crispers);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        } else if (cnt == 7) {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.grain);
            this.sct.setAdapter((ListAdapter)arrayAdapter);
        }
        this.sct.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            /*
             * Enabled aggressive block sorting
             */
            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                if (BajarSamiti_Panel.Quantity == 1) {
                    SubCategory.scatCnt = n + 1;
                    SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                    Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                    Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddQty.class);
                    SubCategory.this.startActivity(intent);
                    return;
                } else {
                    if (BazarsamitiViewRates.visited == 1) {
                        SubCategory.scatCnt = n + 1;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), ViewRates.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n == 0) {
                        SubCategory.scatCnt = 1;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n == 1) {
                        SubCategory.scatCnt = 2;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n == 2) {
                        SubCategory.scatCnt = 3;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n == 3) {
                        SubCategory.scatCnt = 4;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n == 4) {
                        SubCategory.scatCnt = 5;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                    if (n != 5) return;
                    {
                        SubCategory.scatCnt = 6;
                        SubCategory.scatnm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)SubCategory.this.getApplicationContext(), (CharSequence)("You have selected" + SubCategory.scatnm), (int)0).show();
                        Intent intent = new Intent(SubCategory.this.getApplicationContext(), AddRate.class);
                        SubCategory.this.startActivity(intent);
                        return;
                    }
                }
            }
        });
    }

}

