/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.TableLayout
 *  android.widget.TableRow
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Login;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

public class Ahwal
extends AppCompatActivity {
    private static final String TAG_RESULTS = "result";
    final Context context = this;
    String day;
    JSONArray peoples = null;
    public String[] products = new String[]{"Mango", "Apple", "Banana", "Chickoo", "Strawberry", "Orange", "Rose", "Sunflower", "Daisy", "Marigold", "Methi", "Palak", "Shepu", "Kothimbir", "Mug", "Chavli", "Harbhara", "Harbhara Dal", "Mug Dal", "Tomato", "Potato", "Brinjal", "Wheat", "Bajara", "Jowar"};
    private ProgressDialog progress;
    public String[] qty;
    public String[] rate;
    String receivedValue = "";
    String stringRate;

    public void init() {
        TableLayout tableLayout = (TableLayout)this.findViewById(2131558572);
        TableRow tableRow = new TableRow((Context)this);
        TextView textView = new TextView((Context)this);
        textView.setText((CharSequence)" Sr.No ");
        textView.setTextColor(-1);
        tableRow.addView((View)textView);
        TextView textView2 = new TextView((Context)this);
        textView2.setText((CharSequence)" Product ");
        textView2.setTextColor(-1);
        tableRow.addView((View)textView2);
        TextView textView3 = new TextView((Context)this);
        textView3.setText((CharSequence)" Unit Price ");
        textView3.setTextColor(-1);
        tableRow.addView((View)textView3);
        TextView textView4 = new TextView((Context)this);
        textView4.setText((CharSequence)" Average qty per day ");
        textView4.setTextColor(-1);
        tableRow.addView((View)textView4);
        tableLayout.addView((View)tableRow);
        for (int i = 0; i < 25; ++i) {
            TableRow tableRow2 = new TableRow((Context)this);
            TextView textView5 = new TextView((Context)this);
            textView5.setText((CharSequence)("" + (i + 1)));
            textView5.setTextColor(-1);
            textView5.setGravity(17);
            tableRow2.addView((View)textView5);
            TextView textView6 = new TextView((Context)this);
            textView6.setText((CharSequence)this.products[i]);
            textView6.setTextColor(-1);
            textView6.setGravity(17);
            tableRow2.addView((View)textView6);
            TextView textView7 = new TextView((Context)this);
            textView7.setText((CharSequence)(this.rate[i] + "/kg"));
            textView7.setTextColor(-1);
            textView7.setGravity(17);
            tableRow2.addView((View)textView7);
            TextView textView8 = new TextView((Context)this);
            textView8.setText((CharSequence)(this.qty[i] + "kg"));
            textView8.setTextColor(-1);
            textView8.setGravity(17);
            tableRow2.addView((View)textView8);
            tableLayout.addView((View)tableRow2);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968607);
        Calendar.getInstance().get(7);
        this.progress = new ProgressDialog(this.context);
        this.progress.setMessage((CharSequence)"Wait...");
        this.progress.setProgressStyle(0);
        this.progress.setIndeterminate(false);
        this.progress.setProgress(0);
        this.progress.setCancelable(false);
        this.progress.show();
        new getdata().execute((Object[])new String[0]);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void showList() {
        this.peoples = new JSONObject(this.receivedValue).getJSONArray(TAG_RESULTS);
        this.rate = new String[this.peoples.length()];
        this.qty = new String[this.peoples.length()];
        for (int i = 0; i < 25; ++i) {
            JSONObject jSONObject = this.peoples.getJSONObject(i);
            this.rate[i] = jSONObject.getString("v1");
        }
        int n = 0;
        for (int i = 25; i < 50; ++n, ++i) {
            JSONObject jSONObject = this.peoples.getJSONObject(i);
            this.qty[n] = jSONObject.getString("v2");
            continue;
        }
        try {
            this.init();
            this.progress.dismiss();
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
            return;
        }
    }

    private class getdata
    extends AsyncTask<String, Void, String> {
        private getdata() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//getRatesQty.php");
            ArrayList arrayList = new ArrayList(1);
            if (Login.Samuname.equals((Object)"")) {
                arrayList.add((Object)new BasicNameValuePair("sam", Login.Samuname));
            } else {
                arrayList.add((Object)new BasicNameValuePair("sam", Login.Samuname));
            }
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                Ahwal.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            Ahwal.this.showList();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

