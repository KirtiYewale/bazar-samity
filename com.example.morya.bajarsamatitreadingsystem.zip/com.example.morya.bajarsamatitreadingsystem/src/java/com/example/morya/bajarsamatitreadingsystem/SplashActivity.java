/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Handler
 *  android.support.v7.app.ActionBar
 *  android.support.v7.app.AppCompatActivity
 *  android.view.Window
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import com.example.morya.bajarsamatitreadingsystem.Login;

public class SplashActivity
extends AppCompatActivity {
    public static int SPLASH_TIME_OUT = 3000;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968622);
        this.getWindow().setFlags(1024, 1024);
        this.setContentView(2130968622);
        this.getSupportActionBar().hide();
        new Handler().postDelayed(new Runnable(){

            public void run() {
                Intent intent = new Intent((Context)SplashActivity.this, Login.class);
                SplashActivity.this.startActivity(intent);
                SplashActivity.this.finish();
            }
        }, (long)SPLASH_TIME_OUT);
    }

}

