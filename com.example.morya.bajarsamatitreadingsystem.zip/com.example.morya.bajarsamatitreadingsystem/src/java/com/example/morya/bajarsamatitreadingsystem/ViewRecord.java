/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.morya.bajarsamatitreadingsystem.ViewInterested;

public class ViewRecord
extends AppCompatActivity {
    TextView a;
    TextView b;
    Button bck;
    TextView c;
    TextView d;
    TextView e;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968628);
        this.a = (TextView)this.findViewById(2131558612);
        this.a.setText((CharSequence)("BazarSamiti        :  " + ViewInterested.samitinm));
        this.b = (TextView)this.findViewById(2131558613);
        this.b.setText((CharSequence)("Farmer's Contact No :  " + ViewInterested.fname));
        this.c = (TextView)this.findViewById(2131558614);
        this.c.setText((CharSequence)("Product            :  " + ViewInterested.fpro));
        this.d = (TextView)this.findViewById(2131558615);
        this.d.setText((CharSequence)("Quantity           :  " + ViewInterested.fqty + " kg"));
        this.e = (TextView)this.findViewById(2131558611);
        this.e.setText((CharSequence)("Date               :  " + ViewInterested.fdate));
        this.bck = (Button)this.findViewById(2131558616);
        this.bck.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ViewRecord.this.finish();
            }
        });
    }

}

