/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.AddRate;
import com.example.morya.bajarsamatitreadingsystem.BazarsamitiViewRates;
import com.example.morya.bajarsamatitreadingsystem.Category;
import com.example.morya.bajarsamatitreadingsystem.Login;
import com.example.morya.bajarsamatitreadingsystem.SubCategory;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

public class ViewRates
extends AppCompatActivity {
    private static final String TAG_RESULTS = "result";
    public static String fcategory;
    public static String fsubcategory;
    TextView cat;
    final Context context = this;
    String d1;
    String d2;
    String d3;
    String d4;
    String d5;
    String d6;
    String d7;
    String day;
    int day1;
    ListView lv;
    JSONArray peoples = null;
    private ProgressDialog progress;
    String[] rate = new String[]{"SAMPLE"};
    String receivedValue = "";
    String stringRate;
    TextView subcat;
    TextView todayrate;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968627);
        this.lv = (ListView)this.findViewById(2131558566);
        this.cat = (TextView)this.findViewById(2131558562);
        this.subcat = (TextView)this.findViewById(2131558563);
        this.todayrate = (TextView)this.findViewById(2131558565);
        fcategory = Category.catnm;
        fsubcategory = SubCategory.scatnm;
        this.cat.setText((CharSequence)("Category :" + fcategory));
        this.subcat.setText((CharSequence)("Sub Category :" + fsubcategory));
        try {
            this.day1 = Calendar.getInstance().get(7);
            this.progress = new ProgressDialog(this.context);
            this.progress.setMessage((CharSequence)"Wait...");
            this.progress.setProgressStyle(0);
            this.progress.setIndeterminate(false);
            this.progress.setProgress(0);
            this.progress.setCancelable(false);
            this.progress.show();
            new getdata().execute((Object[])new String[0]);
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
            return;
        }
    }

    protected void showList() {
        try {
            this.peoples = new JSONObject(this.receivedValue).getJSONArray(TAG_RESULTS);
            JSONObject jSONObject = this.peoples.getJSONObject(0);
            this.d1 = "Sunday  Rs. " + jSONObject.getString("v1") + "/-";
            this.d2 = "Monday  Rs. " + jSONObject.getString("v2") + "/-";
            this.d3 = "Tuesday  Rs. " + jSONObject.getString("v3") + "/-";
            this.d4 = "Wednesday  Rs. " + jSONObject.getString("v4") + "/-";
            this.d5 = "Thursday  Rs. " + jSONObject.getString("v5") + "/-";
            this.d6 = "Friday  Rs. " + jSONObject.getString("v6") + "/-";
            this.d7 = "Saturday  Rs. " + jSONObject.getString("v7") + "/-";
            Object[] arrobject = new String[]{this.d1, this.d2, this.d3, this.d4, this.d5, this.d6, this.d7};
            this.day1 = -1 + this.day1;
            this.todayrate.setText((CharSequence)(arrobject[this.day1] + " per kg"));
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 2130968670, arrobject);
            this.lv.setAdapter((ListAdapter)arrayAdapter);
            this.progress.dismiss();
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
            return;
        }
    }

    private class addUser
    extends AsyncTask<String, Void, String> {
        private addUser() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//addRate.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("e1", ViewRates.this.stringRate));
            arrayList.add((Object)new BasicNameValuePair("pn", ViewRates.fsubcategory));
            arrayList.add((Object)new BasicNameValuePair("day", ViewRates.this.day));
            arrayList.add((Object)new BasicNameValuePair("samiti", Login.unameString));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                ViewRates.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            ViewRates.this.progress.dismiss();
            Toast.makeText((Context)ViewRates.this.context, (CharSequence)ViewRates.this.receivedValue, (int)0).show();
            if (ViewRates.this.receivedValue.contains((CharSequence)"exists")) {
                Toast.makeText((Context)ViewRates.this.context, (CharSequence)"UserId Already Exists", (int)0).show();
                return;
            } else {
                if (!ViewRates.this.receivedValue.contains((CharSequence)"success")) return;
                {
                    Toast.makeText((Context)ViewRates.this.context, (CharSequence)"Rate Updated Successfully", (int)0).show();
                    Intent intent = new Intent(ViewRates.this.getApplicationContext(), AddRate.class);
                    ViewRates.this.startActivity(intent);
                    ViewRates.this.finish();
                    return;
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

    private class getdata
    extends AsyncTask<String, Void, String> {
        private getdata() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//getRates.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("sub", ViewRates.fsubcategory));
            arrayList.add((Object)new BasicNameValuePair("sam", BazarsamitiViewRates.samitinm));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                ViewRates.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            ViewRates.this.showList();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

