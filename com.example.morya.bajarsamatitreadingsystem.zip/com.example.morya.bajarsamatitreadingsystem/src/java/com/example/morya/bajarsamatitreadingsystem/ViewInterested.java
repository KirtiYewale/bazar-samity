/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Login;
import com.example.morya.bajarsamatitreadingsystem.ViewRecord;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

public class ViewInterested
extends AppCompatActivity {
    private static final String TAG_RESULTS = "result";
    public static String fdate;
    public static String fname;
    public static String fpro;
    public static String fqty;
    public static int samiticnt;
    public static String samitinm;
    public static int visited;
    String[] BajarSamiti;
    ListView bl;
    final Context context = this;
    String[] date;
    String day;
    int day1;
    String[] name;
    JSONArray peoples = null;
    String[] product;
    private ProgressDialog progress;
    String[] qt;
    String receivedValue = "";
    String stringRate;

    static {
        samiticnt = 0;
        visited = 0;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968625);
        this.bl = (ListView)this.findViewById(2131558574);
        this.progress = new ProgressDialog(this.context);
        this.progress.setMessage((CharSequence)"Wait...");
        this.progress.setProgressStyle(0);
        this.progress.setIndeterminate(false);
        this.progress.setProgress(0);
        this.progress.setCancelable(false);
        this.progress.show();
        new getdata().execute((Object[])new String[0]);
        this.bl.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                ViewInterested.samiticnt = n + 1;
                ViewInterested.samitinm = ViewInterested.this.BajarSamiti[n];
                ViewInterested.fname = ViewInterested.this.name[n];
                ViewInterested.fdate = ViewInterested.this.date[n];
                ViewInterested.fpro = ViewInterested.this.product[n];
                ViewInterested.fqty = ViewInterested.this.qt[n];
                Toast.makeText((Context)ViewInterested.this.getApplicationContext(), (CharSequence)("" + ViewInterested.samitinm), (int)0).show();
                ViewInterested.visited = 1;
                ViewInterested.this.startActivity(new Intent(ViewInterested.this.getApplicationContext(), ViewRecord.class));
                ViewInterested.this.finish();
            }
        });
    }

    protected void showList() {
        this.peoples = new JSONObject(this.receivedValue).getJSONArray(TAG_RESULTS);
        this.BajarSamiti = new String[this.peoples.length()];
        this.name = new String[this.peoples.length()];
        this.date = new String[this.peoples.length()];
        this.product = new String[this.peoples.length()];
        this.qt = new String[this.peoples.length()];
        int n = 0;
        do {
            if (n >= this.peoples.length()) break;
            JSONObject jSONObject = this.peoples.getJSONObject(n);
            this.BajarSamiti[n] = jSONObject.getString("v2");
            this.name[n] = jSONObject.getString("v1");
            this.date[n] = jSONObject.getString("v3");
            this.product[n] = jSONObject.getString("v4");
            this.qt[n] = jSONObject.getString("v5");
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.name);
            this.bl.setAdapter((ListAdapter)arrayAdapter);
            this.progress.dismiss();
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)("Error3=" + exception.toString()), (int)0).show();
            return;
        }
    }

    private class getdata
    extends AsyncTask<String, Void, String> {
        private getdata() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//getInterested.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("sam", Login.unameString));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                ViewInterested.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            ViewInterested.this.showList();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

