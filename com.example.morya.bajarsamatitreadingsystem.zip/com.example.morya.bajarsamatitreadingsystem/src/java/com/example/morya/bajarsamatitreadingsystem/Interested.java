/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.DatePicker
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ResponseHandler
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.BasicResponseHandler
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.message.BasicNameValuePair
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Login;
import com.example.morya.bajarsamatitreadingsystem.User;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class Interested
extends AppCompatActivity {
    EditText bazar;
    private Calendar calendar;
    final Context context = this;
    String d;
    TextView date;
    private DatePicker datePicker;
    private int day;
    private int month;
    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener(){

        public void onDateSet(DatePicker datePicker, int n, int n2, int n3) {
            Interested.this.showDate(n, n2 + 1, n3);
        }
    };
    String pro;
    EditText product;
    private ProgressDialog progress;
    String q;
    EditText qty;
    String receivedValue = "";
    String sam;
    Button sub;
    private int year;

    private void showDate(int n, int n2, int n3) {
        this.date.setText((CharSequence)new StringBuilder().append(n3).append("/").append(n2).append("/").append(n));
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968617);
        this.bazar = (EditText)this.findViewById(2131558596);
        this.product = (EditText)this.findViewById(2131558597);
        this.qty = (EditText)this.findViewById(2131558598);
        this.sub = (Button)this.findViewById(2131558600);
        this.date = (TextView)this.findViewById(2131558599);
        this.calendar = Calendar.getInstance();
        this.year = this.calendar.get(1);
        this.month = this.calendar.get(2);
        this.day = this.calendar.get(5);
        this.showDate(this.year, 1 + this.month, this.day);
        this.date.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Interested.this.setDate(view);
            }
        });
        this.sub.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Interested.this.sam = Interested.this.bazar.getText().toString();
                Interested.this.pro = Interested.this.product.getText().toString();
                Interested.this.q = Interested.this.qty.getText().toString();
                Interested.this.d = Interested.this.date.getText().toString();
                if (Interested.this.sam.equals((Object)"")) {
                    Interested.this.bazar.setError((CharSequence)"Enter Name");
                    return;
                }
                if (Interested.this.pro.equals((Object)"")) {
                    Interested.this.product.setError((CharSequence)"Check Mobile no");
                    return;
                }
                if (Interested.this.q.equals((Object)"")) {
                    Interested.this.qty.setError((CharSequence)"Enter Address");
                    return;
                }
                if (Interested.this.d.equals((Object)"")) {
                    Toast.makeText((Context)Interested.this.context, (CharSequence)"Enter date Please", (int)0).show();
                    return;
                }
                try {
                    Interested.this.progress = new ProgressDialog(Interested.this.context);
                    Interested.this.progress.setMessage((CharSequence)"Wait...");
                    Interested.this.progress.setProgressStyle(0);
                    Interested.this.progress.setIndeterminate(false);
                    Interested.this.progress.setProgress(0);
                    Interested.this.progress.setCancelable(false);
                    Interested.this.progress.show();
                    new addUser().execute((Object[])new String[0]);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)Interested.this.context, (CharSequence)("Error=" + exception.toString()), (int)0).show();
                    return;
                }
            }
        });
    }

    protected Dialog onCreateDialog(int n) {
        if (n == 999) {
            return new DatePickerDialog((Context)this, this.myDateListener, this.year, this.month, this.day);
        }
        return null;
    }

    public void setDate(View view) {
        this.showDialog(999);
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)"ca", (int)0).show();
    }

    private class addUser
    extends AsyncTask<String, Void, String> {
        private addUser() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ String doInBackground(String ... arrstring) {
            HttpPost httpPost;
            DefaultHttpClient defaultHttpClient;
            defaultHttpClient = new DefaultHttpClient();
            httpPost = new HttpPost("http://bazarsamiti.co.nf//addInterest.php");
            ArrayList arrayList = new ArrayList(1);
            arrayList.add((Object)new BasicNameValuePair("e1", Interested.this.sam));
            arrayList.add((Object)new BasicNameValuePair("e2", Interested.this.pro));
            arrayList.add((Object)new BasicNameValuePair("e3", Interested.this.q));
            arrayList.add((Object)new BasicNameValuePair("e4", Interested.this.d));
            arrayList.add((Object)new BasicNameValuePair("e5", Login.unameString));
            try {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)arrayList));
            }
            catch (Exception exception) {}
            try {
                BasicResponseHandler basicResponseHandler = new BasicResponseHandler();
                Interested.this.receivedValue = (String)defaultHttpClient.execute((HttpUriRequest)httpPost, (ResponseHandler)basicResponseHandler);
                return "";
            }
            catch (Exception exception) {
                return "";
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            Interested.this.progress.dismiss();
            Toast.makeText((Context)Interested.this.context, (CharSequence)Interested.this.receivedValue, (int)0).show();
            if (Interested.this.receivedValue.contains((CharSequence)"exists")) {
                Toast.makeText((Context)Interested.this.context, (CharSequence)"UserId Already Exists", (int)0).show();
                return;
            } else {
                if (!Interested.this.receivedValue.contains((CharSequence)"success")) return;
                {
                    Toast.makeText((Context)Interested.this.context, (CharSequence)"Your Interest Subimtted Successfully!!", (int)0).show();
                    Intent intent = new Intent(Interested.this.getApplicationContext(), User.class);
                    Interested.this.startActivity(intent);
                    Interested.this.finish();
                    return;
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected /* varargs */ void onProgressUpdate(Void ... arrvoid) {
            super.onProgressUpdate((Object[])arrvoid);
        }
    }

}

