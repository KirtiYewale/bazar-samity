/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.support.design.widget.NavigationView
 *  android.support.design.widget.NavigationView$OnNavigationItemSelectedListener
 *  android.support.v4.widget.DrawerLayout
 *  android.support.v4.widget.DrawerLayout$DrawerListener
 *  android.support.v7.app.ActionBarDrawerToggle
 *  android.support.v7.app.AppCompatActivity
 *  android.support.v7.widget.Toolbar
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Locale
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import com.example.morya.bajarsamatitreadingsystem.Ahwal;
import com.example.morya.bajarsamatitreadingsystem.BazarsamitiViewRates;
import com.example.morya.bajarsamatitreadingsystem.Category;
import com.example.morya.bajarsamatitreadingsystem.Login;
import com.example.morya.bajarsamatitreadingsystem.ViewInterested;
import com.example.morya.bajarsamatitreadingsystem.simplebajarsamitilist;
import java.util.HashMap;
import java.util.Locale;

public class BajarSamiti_Panel
extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener {
    public static int Quantity = 0;
    TextToSpeech t1;

    public void onBackPressed() {
        DrawerLayout drawerLayout = (DrawerLayout)this.findViewById(2131558567);
        if (drawerLayout.isDrawerOpen(8388611)) {
            drawerLayout.closeDrawer(8388611);
            return;
        }
        super.onBackPressed();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968609);
        Toolbar toolbar = (Toolbar)this.findViewById(2131558617);
        this.setSupportActionBar(toolbar);
        this.t1 = new TextToSpeech(this.getApplicationContext(), new TextToSpeech.OnInitListener(){

            public void onInit(int n) {
                if (n != -1) {
                    BajarSamiti_Panel.this.t1.setLanguage(Locale.UK);
                    BajarSamiti_Panel.this.t1.speak("Welcome to Bazar Samiti Panel", 0, null);
                }
            }
        });
        DrawerLayout drawerLayout = (DrawerLayout)this.findViewById(2131558567);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, drawerLayout, toolbar, 2131165223, 2131165222);
        drawerLayout.setDrawerListener((DrawerLayout.DrawerListener)actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        ((NavigationView)this.findViewById(2131558568)).setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener)this);
    }

    public boolean onCreateOptionsMenu(Menu menu2) {
        this.getMenuInflater().inflate(2131623940, menu2);
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onNavigationItemSelected(MenuItem menuItem) {
        int n = menuItem.getItemId();
        if (n == 2131558660) {
            this.startActivity(new Intent(this.getApplicationContext(), simplebajarsamitilist.class));
        } else if (n == 2131558661) {
            this.startActivity(new Intent(this.getApplicationContext(), BazarsamitiViewRates.class));
        } else if (n == 2131558468) {
            BazarsamitiViewRates.visited = 0;
            this.startActivity(new Intent(this.getApplicationContext(), Category.class));
        } else if (n == 2131558665) {
            this.startActivity(new Intent(this.getApplicationContext(), ViewInterested.class));
        } else if (n == 2131558666) {
            Quantity = 1;
            this.startActivity(new Intent(this.getApplicationContext(), Category.class));
        } else if (n == 2131558667) {
            Quantity = 1;
            this.startActivity(new Intent(this.getApplicationContext(), Ahwal.class));
        }
        ((DrawerLayout)this.findViewById(2131558567)).closeDrawer(8388611);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 2131558670) {
            this.startActivity(new Intent(this.getApplicationContext(), Login.class));
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    protected void onResume() {
        super.onResume();
        Quantity = 0;
    }

}

