/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ComparePrices
extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968612);
    }
}

