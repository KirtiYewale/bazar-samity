/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.example.morya.bajarsamatitreadingsystem.Category;

public class BajarSamiti
extends AppCompatActivity {
    public static int samiticnt = 0;
    public static String samitinm;
    String[] BajarSamiti = new String[]{"Baramati", "Pune", "Indapur", "Phaltan", "Kolhapur", "Satara", "Solapur"};
    ListView bl;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968608);
        this.bl = (ListView)this.findViewById(2131558574);
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])this.BajarSamiti);
        this.bl.setAdapter((ListAdapter)arrayAdapter);
        this.bl.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            /*
             * Enabled aggressive block sorting
             */
            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                if (n == 0) {
                    BajarSamiti.samiticnt = 1;
                    BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                    Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                    Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                    BajarSamiti.this.startActivity(intent);
                    return;
                } else {
                    if (n == 1) {
                        BajarSamiti.samiticnt = 2;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                    if (n == 2) {
                        BajarSamiti.samiticnt = 3;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                    if (n == 3) {
                        BajarSamiti.samiticnt = 4;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                    if (n == 4) {
                        BajarSamiti.samiticnt = 5;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                    if (n == 5) {
                        BajarSamiti.samiticnt = 6;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                    if (n != 6) return;
                    {
                        BajarSamiti.samiticnt = 7;
                        BajarSamiti.samitinm = (String)adapterView.getItemAtPosition(n);
                        Toast.makeText((Context)BajarSamiti.this, (CharSequence)("You have selected" + BajarSamiti.samitinm), (int)0).show();
                        Intent intent = new Intent(BajarSamiti.this.getApplicationContext(), Category.class);
                        BajarSamiti.this.startActivity(intent);
                        return;
                    }
                }
            }
        });
    }

}

