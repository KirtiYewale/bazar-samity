/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.example.morya.bajarsamatitreadingsystem;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import java.util.ArrayList;
import java.util.List;

public class FarmerIntrest
extends AppCompatActivity {
    public static String category;
    Button add;
    Spinner bajar;
    Spinner cat;
    Spinner subcat;
    public int subcnt = 0;
    EditText value;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968616);
        this.add = (Button)this.findViewById(2131558468);
        this.cat = (Spinner)this.findViewById(2131558562);
        this.subcat = (Spinner)this.findViewById(2131558563);
        this.value = (EditText)this.findViewById(2131558595);
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"Fruits");
        arrayList.add((Object)"Vegetables");
        arrayList.add((Object)"Flowers");
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (List)arrayList);
        arrayAdapter.setDropDownViewResource(17367049);
        this.cat.setAdapter((SpinnerAdapter)arrayAdapter);
        category = this.cat.getSelectedItem().toString();
        this.cat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                FarmerIntrest.this.subcnt = n;
                FarmerIntrest.this.subList();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    public void subList() {
        ArrayList arrayList = new ArrayList();
        if (this.subcnt == 0) {
            arrayList.add((Object)"Site");
            arrayList.add((Object)"Enginner");
            arrayList.add((Object)"Construction Labour");
            arrayList.add((Object)"Architecher Draftman");
            arrayList.add((Object)"Gentarl Labour");
            arrayList.add((Object)"Painter");
            arrayList.add((Object)"Interior Designer");
            arrayList.add((Object)"Plumbing");
        } else if (this.subcnt == 1) {
            arrayList.add((Object)"Wireman");
            arrayList.add((Object)"TV repairing");
            arrayList.add((Object)"AC Repairing");
            arrayList.add((Object)"All Electricen Reparing");
        } else if (this.subcnt == 2) {
            arrayList.add((Object)"Animal care");
            arrayList.add((Object)"Service Worker");
            arrayList.add((Object)"Agriculture product store");
            arrayList.add((Object)"Fertilizers");
            arrayList.add((Object)"Seeds");
        } else if (this.subcnt == 3) {
            arrayList.add((Object)"Wood");
            arrayList.add((Object)"Meal");
            arrayList.add((Object)"Plastic");
            arrayList.add((Object)"Glass");
        } else if (this.subcnt == 4) {
            arrayList.add((Object)"Wireman");
            arrayList.add((Object)"Enginner");
            arrayList.add((Object)"Construction Labour");
            arrayList.add((Object)"Architecher Draftman");
            arrayList.add((Object)"Gentarl Labour");
            arrayList.add((Object)"Painter");
            arrayList.add((Object)"Interior Designer");
            arrayList.add((Object)"Plumbing");
        } else if (this.subcnt == 5) {
            arrayList.add((Object)"AC");
            arrayList.add((Object)"TV");
            arrayList.add((Object)"Mobile");
            arrayList.add((Object)"Laptop");
            arrayList.add((Object)"Motorcycle");
            arrayList.add((Object)"Refrigerator");
            arrayList.add((Object)"Elevator");
        } else if (this.subcnt == 6) {
            arrayList.add((Object)"Carpenters");
            arrayList.add((Object)"Criver services");
            arrayList.add((Object)"Duplicate Key maker");
            arrayList.add((Object)"Electrician");
            arrayList.add((Object)"Plumbing");
            arrayList.add((Object)"Towing");
        } else if (this.subcnt == 7) {
            arrayList.add((Object)"Sell");
            arrayList.add((Object)"Buy");
            arrayList.add((Object)"PG Hostels");
        } else if (this.subcnt == 8) {
            arrayList.add((Object)"Administration");
            arrayList.add((Object)"Basic Computing");
            arrayList.add((Object)"Computer Hardware Training");
            arrayList.add((Object)"Database training");
            arrayList.add((Object)"Mobile Development");
        } else if (this.subcnt == 9) {
            arrayList.add((Object)"XUV");
            arrayList.add((Object)"Transport");
            arrayList.add((Object)"Tanker");
            arrayList.add((Object)"Ambulance");
            arrayList.add((Object)"Luxury");
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (List)arrayList);
        arrayAdapter.setDropDownViewResource(17367049);
        this.subcat.setAdapter((SpinnerAdapter)arrayAdapter);
    }

}

